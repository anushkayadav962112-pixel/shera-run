# SHERA RUN — Complete AAA Visual Quality Overhaul

A complete 3D art-direction, lighting, character, environment, and mobile portrait UI overhaul of the existing playable **SHERA RUN** endless runner. All existing gameplay mechanics, 150 stages, economy, missions, progression, audio, and local persistence remain intact while eliminating white overexposure and replacing boxy primitives with commercial-grade 3D geometry and PBR textures.

---

### User Review & Critical Decisions

> [!IMPORTANT] Because the Phase 1 clarifying questions were skipped, this plan adopts the recommended art-direction and compatibility decisions below. Review before approving.

- **Decision 1 — World 5 Identity (`Frozen Kingdom`) & World 3–4 Alignment**: World 3 will be themed as **Crystal Forest** (giant colorful crystals and magical glowing trees alongside Royal Express rails), World 4 as **Dragon Kingdom** (ancient mountain stone castles, dragons, and alpine bridges), and World 5 upgraded to **Frozen Kingdom** (snowy mountains, ice castles, and frozen lakes with Golden/Frost Express trains). Existing player unlocks, stages 121–150, and World 5 high scores will automatically migrate without losing progress.
- **Decision 2 — Lighting, Exposure & Bloom Removal**: Uncontrolled post-processing bloom (`UnrealBloomPass`) and excessive exponential fog will be removed. Rendering will use direct ACES Filmic tone mapping (`exposure ~0.95`), calibrated studio environment reflections, warm-sun vs. cool-sky lighting contrast, and baked ambient occlusion so Shera's white fur and mane retain crisp shadow separation against deep blue skies.
- **Decision 3 — Full Organic Sculpt Rebuild of Shera**: Shera's head, layered mane, muzzle, sunglasses, tailored suit, wristwatch, sneakers, paws, and tail will be rebuilt using sculpted organic curves (`LatheGeometry`, beveled `ExtrudeGeometry`, `TubeGeometry`, and layered tufts) matching the attached character sheet and seated crossed-leg throne pose.

---

### 1. Overview & Core Concept

- **What It Does**: Transforms the existing 3D endless runner into a crisp, richly saturated fantasy mobile experience where Shera—an anthropomorphic white lion in a tailored white luxury suit, black tie, thick gold chain, golden wristwatch, and dark sunglasses—reigns over a detailed red-and-gold throne on the Home screen and sprints across five distinct 3D fantasy kingdoms.
- **Target Audience & Context**: Android portrait mobile players (360–430px viewports) and desktop browsers, designed for smooth 60 FPS mid-range mobile WebGL performance and Capacitor Android packaging.
- **Key Value**: Fixes the washed-out white glare and blocky geometry while keeping every working system (150 stages, 8 power-ups, 5 outfits, 5 hoverboards, revives, shop, missions, daily rewards, lucky spin, and local save storage) 100% functional.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Home Throne Showcase**: Opens directly to Shera seated in a relaxed crossed-leg royal pose (one paw on the sculpted golden lion armrest showing his watch, the other adjusting his sunglasses) atop a stepped stone dais surrounded by floating castles, waterfalls, and deep blue skies. Left/right jewel-beveled feature rails, a prominent gold **PLAY** CTA, and the 4-tab bottom bar remain clear of the central character silhouette.
  2. **In-Run 3-Lane Gameplay**: Smooth third-person chase camera with subtle banking on lane switches, grounded contact shadows, articulated running/jumping/double-jumping/sliding/hoverboard/rocket/stumble/victory poses, readable obstacles, gleaming embossed lion coins, and clean spark/dust particle bursts without blinding bloom.
  3. **Progression & Recovery**: Clearing stage distance milestones celebrates mid-run and unlocks subsequent stages; collisions transition cleanly to Run Ended with score breakdown, Gem Revive, Rewarded Ad SDK bridge check, Restart, and Home return.

- **Visual Identity & Theme**:
  - **Aesthetic Direction**: High-craft stylized 3D fantasy arcade aesthetic—deep cobalt/azure skies, warm golden architectural highlights, lush emerald/pink foliage, and rich stone/basalt/ice surface relief.
  - **Color Palette & Lighting Balance**:
    - *3D Environment*: Deep sky cobalt (`#1043a8` to `#4fa7f5`), natural sandstone/granite track values (`#8e8275`), warm sunlight key (`#ffe7b8`), cool hemisphere bounce (`#7cc2ff` / `#5d4c3b`), and restrained horizon mist (`density <= 0.0022`).
    - *Shera Fur & Suit Contrast*: Warm ivory-cream under-fur (`#e8dfd0`) with procedural strand normal/bump and crease ambient occlusion paired against crisp tailored ivory-white jacket (`#f4f5f8`), matte charcoal silk tie (`#141821`), brushed 24k gold chain/watch (`#f2b429`), and glossy dark sunglasses (`#0c1018`).
    - *UI Surfaces*: Deep midnight navy (`#0b142d`), burnished gold frames (`#f59e0b` / `#fde047`), sky-steel highlights (`#38bdf8`), and legible tabular numeric readouts.
  - **Typography & Hierarchy**: Replace default `Inter` with characterful geometric display (`Outfit` / `Plus Jakarta Sans`) plus `tabular-nums` alignment for scores, distance counters, coins, gems, and stage progress.
  - **Mobile Portrait Ergonomics**: Minimum 44x44px hit targets on all buttons, compact top HUD bar, non-obstructive left power-up quick-slots (displaying active/stocked items cleanly with optional expand), and generous breathing room around the central runner lane.

- **Interactive Feedback & Motion**:
  - Crisp 120–180ms button press scale transitions (`transform` only, zero `backdrop-blur` over the WebGL canvas).
  - Frame-rate-independent exponential damping on lane switches, squash-and-stretch jump landings, FOV speed ramps, hitstop micro-shake on shield/hoverboard saves, and animated coin magnet trails.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Direct ACES Tone Mapping + Baked AO Over Post-Processing Bloom**
  - *Chosen Approach*: Remove multi-pass `EffectComposer` + `UnrealBloomPass` from the default render path, calibrate `toneMappingExposure` below `1.0`, cap environment reflection intensity on non-metals, and paint procedural ambient occlusion / crease maps directly into fur, stone, and obstacle textures.
  - *Why*: Eliminates blown-out white pixels on Shera's fur and suit, restores sky-to-character silhouette contrast, and cuts fragment fill-rate overhead on mid-range Android GPUs.
  - *Alternatives Considered*: Keeping selective bloom layers (rejected because extra render targets hurt mobile framerates and easily blow out ivory/white materials).

- **Decision 2 — Sculpted Organic Sub-Parts & Shared Geometry Pooling**
  - *Chosen Approach*: Rebuild Shera and world props using `LatheGeometry`, beveled `ExtrudeGeometry`, `TubeGeometry`, and layered spherical tufts while sharing geometries/materials across pooled track chunks and obstacles.
  - *Why*: Achieves movie-grade rounded feline anatomy, expressive brow/muzzle forms, detailed stone curbs/balustrades, and dense multi-crown trees without increasing per-frame draw-call or GC pressure.
  - *Alternatives Considered*: Loading heavy external GLB files (rejected to guarantee zero network/404 asset failures and instant offline startup in Android WebViews).

- **Decision 3 — Automatic Legacy Save Compatibility for World 5 (`Frozen Kingdom`)**
  - *Chosen Approach*: Map World 5 to `frozen` (**Frozen Kingdom**) with automatic migration of prior `'desert'` save entries, World 3 updated to **Crystal Forest**, and World 4 updated to **Dragon Kingdom**.
  - *Why*: Delivers every environment explicitly requested in the overhaul brief while honoring the rule to preserve all 5 unlocked worlds, 150 stages, and player high scores.
  - *Alternatives Considered*: Keeping a desert 5th world (rejected because Section 6 explicitly specifies Frozen Kingdom with snowy mountains, ice castles, and frozen lakes).

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

```
┌───────────────────────────────────────────────────────────────────────────┐
│                         APPLICATION SHELL & UI LAYER                      │
│  [Portrait HUD] ── [Home Throne Overlay] ── [Modals: Worlds/Shop/Profile] │
└───────────────┬───────────────────────────────┬───────────────────────────┘
                │ Commands / Inputs             │ Persisted State Sync
                ▼                               ▼
┌───────────────────────────────┐   ┌───────────────────────────────────────┐
│     3D GAME ENGINE CORE       │   │     SAVE & PROGRESSION STORE          │
│ • Calibrated PBR Lighting Rig │   │ • LocalStorage Migration & Telemetry  │
│ • Direct ACES Renderer        │   │ • 5 Worlds / 150 Stages / Missions    │
│ • Smooth Chase Camera & Shake │   │ • 5 Outfits / 5 Boards / 8 PowerUps   │
└───┬───────────┬───────────┬───┘   │ • Native Ad/IAP Bridge Detection      │
    │           │           │       └───────────────────────────────────────┘
    ▼           ▼           ▼
┌─────────┐ ┌──────────┐ ┌──────────────────┐
│  SHERA  │ │ 5 WORLDS │ │ POOLED OBSTACLES │
│  RIG    │ │  ENGINE  │ │ & COLLECTIBLES   │
│ Sculpt  │ │ Cloud /  │ │ Trains / Wyverns │
│ Fur+AO  │ │ Lava /   │ │ Spikes / Ramps / │
│ 12 Anim │ │ Crystal /│ │ Coins / PowerUps │
│ States  │ │ Dragon / │ │ & Particles      │
│         │ │ Frozen   │ │                  │
└─────────┘ └──────────┘ └──────────────────┘
```

- **Data Model & State**:
  - `WorldId` evolves to `'clouds' | 'lava' | 'crystal' | 'dragon' | 'frozen'`, with automatic migration from `'trains'`, `'forest'`, and `'desert'` inside the storage loader so existing user saves load seamlessly.
  - `PlayerSaveData` retains all currency, XP/level, mission, achievement, outfit, hoverboard, power-up inventory/level, and audio/touch/graphics-quality (`low | medium | high`) settings.
- **Interactive Component & State Mapping**:
  - **Settings Graphics Toggle**: Scales shadow map resolution, pixel ratio (`1.0` / `1.5` / `2.0`), and particle density without enabling blown-out bloom.
  - **Home Screen & Modals**: Every home rail icon (`Daily Reward`, `Lucky Spin`, `Free Coins`, `Missions`, `VIP Pass`, `Events`, `Leaderboard`, `Starter Pack`), bottom navigation tab (`Characters`, `Hoverboards`, `Worlds`, `Shop`), profile pill, and **PLAY** button connects directly to live state updates and engine world/outfit/hoverboard syncing.
  - **Gameplay Controls & Feedback**: Touch swipes, optional portrait accessibility buttons, and desktop keyboard controls (`Arrow`/`WASD`/`Space`/`1`–`8`/`Esc`) drive the real-time runner loop, collision checks, Shield/Hoverboard stumbles, Invincibility obstacle smashes, Stage Milestone celebrations, Game Over summary, and Gem/Ad-bridge Revive.

import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.shera.run',
  appName: 'SHERA RUN',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
